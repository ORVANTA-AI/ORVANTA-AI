from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles
from .config import settings
from .schemas import AnalysisRequest, RiskRequest
from .engine import analyze, calculate_risk

app = FastAPI(title="ORVANTA AI API", version="0.1.0")

@app.get("/api/health")
def health():
    return {"ok": True, "service": "ORVANTA AI"}

@app.post("/api/analyze")
def api_analyze(req: AnalysisRequest):
    return analyze(req.symbol, req.timeframe)

@app.post("/api/risk")
def api_risk(req: RiskRequest):
    return calculate_risk(req)

@app.get("/api/admin/overview")
def admin_overview(x_admin_key: str | None = Header(default=None)):
    if x_admin_key != settings.admin_api_key:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {
        "users": 0,
        "active_users": 0,
        "pro_users": 0,
        "signals_today": 0,
        "status": "MVP"
    }

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
