from pydantic import BaseModel, Field
from typing import Literal

class AnalysisRequest(BaseModel):
    symbol: str = "XAUUSD"
    timeframe: str = "M5"

class Signal(BaseModel):
    symbol: str
    timeframe: str
    side: Literal["BUY", "SELL", "WAIT"]
    strength: int = Field(ge=0, le=100)
    entry: float | None = None
    stop_loss: float | None = None
    tp1: float | None = None
    tp2: float | None = None
    setup: str
    reasons: list[str]
    risk: str = "MODERATE"

class RiskRequest(BaseModel):
    balance: float = Field(gt=0)
    risk_percent: float = Field(gt=0, le=100)
    entry: float = Field(gt=0)
    stop_loss: float = Field(gt=0)
    value_per_price_unit: float = Field(default=1.0, gt=0)

class RiskResponse(BaseModel):
    max_risk_amount: float
    stop_distance: float
    position_size_units: float
