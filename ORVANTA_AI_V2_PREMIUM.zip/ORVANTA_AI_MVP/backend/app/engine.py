from .schemas import Signal, RiskRequest, RiskResponse

def analyze(symbol: str, timeframe: str) -> Signal:
    # Placeholder: production version will consume live OHLCV data and
    # calculate EMA/ADX/RSI/ATR + breakout/retest/confirmation.
    return Signal(
        symbol=symbol.upper(),
        timeframe=timeframe.upper(),
        side="WAIT",
        strength=0,
        setup="NO_DATA",
        reasons=[
            "Market-data adapter is not connected yet",
            "No signal is issued until live data and confirmation rules are available",
        ],
        risk="UNKNOWN",
    )

def calculate_risk(req: RiskRequest) -> RiskResponse:
    max_risk = req.balance * req.risk_percent / 100.0
    distance = abs(req.entry - req.stop_loss)
    size = 0.0 if distance == 0 else max_risk / (distance * req.value_per_price_unit)
    return RiskResponse(
        max_risk_amount=round(max_risk, 4),
        stop_distance=round(distance, 6),
        position_size_units=round(size, 6),
    )
