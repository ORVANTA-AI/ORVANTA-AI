from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    telegram_bot_token: str = ""
    app_base_url: str = "http://127.0.0.1:8000"
    admin_api_key: str = "change-me"
    ai_provider: str = ""
    ai_api_key: str = ""
    market_data_provider: str = ""
    market_data_api_key: str = ""
    database_url: str = "sqlite:///./orvanta.db"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
