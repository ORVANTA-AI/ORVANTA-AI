import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message, WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
from .app.config import settings

dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🚀 OPEN ORVANTA",
            web_app=WebAppInfo(url=settings.app_base_url)
        )],
        [
            InlineKeyboardButton(text="⚡ LIVE SIGNALS", callback_data="signals"),
            InlineKeyboardButton(text="🤖 AI ANALYST", callback_data="analyst")
        ],
        [
            InlineKeyboardButton(text="💎 ORVANTA PRO", callback_data="pro")
        ]
    ])
    await message.answer(
        "🧠 <b>ORVANTA AI</b>\n\n"
        "AI-powered market intelligence.\n"
        "افتح المنصة لبدء التحليل.",
        reply_markup=kb,
        parse_mode="HTML"
    )

async def main():
    if not settings.telegram_bot_token:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN in .env")
    bot = Bot(settings.telegram_bot_token)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
