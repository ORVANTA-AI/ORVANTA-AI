# ORVANTA AI — MVP

منصة ذكاء وتحليل الأسواق عبر Telegram + Mini App.

## الهدف
هذه النسخة هي الهيكل الأول للمشروع، وتشمل:
- Telegram Bot
- Mini App واجهة Dashboard
- محرك إشارات قابل للتوسعة
- Market Scanner
- AI Analyst endpoint (جاهز للربط بمزود AI)
- Risk Calculator
- News/Market data adapters
- Admin API skeleton
- Docker Compose

> هذه النسخة لا تنفذ صفقات حقيقية ولا تحتوي مفاتيح API أو بيانات سوق مدفوعة.
> قبل الإطلاق التجاري يجب إضافة مزود بيانات سوق موثوق، مفاتيح Telegram، نظام اشتراكات/دفع، ومراجعة أمنية.

## التشغيل السريع

1. انسخ `.env.example` إلى `.env`.
2. ضع `TELEGRAM_BOT_TOKEN`.
3. ثبّت Python 3.11+.
4. شغّل:
   ```bash
   pip install -r backend/requirements.txt
   uvicorn backend.app.main:app --reload
   ```
5. افتح:
   `http://127.0.0.1:8000`
6. لتشغيل البوت:
   ```bash
   python -m backend.bot
   ```

## الهيكل

- `backend/app/` API + محرك التحليل
- `backend/bot.py` Telegram bot
- `frontend/` Mini App
- `docker-compose.yml` للتشغيل لاحقاً
- `.env.example` إعدادات البيئة

## مراحل التطوير التالية

### V0.2
- ربط بيانات XAUUSD/Forex/Crypto الحية
- Breakout + Retest + Confirmation
- EMA/ADX/RSI/ATR
- Multi-timeframe
- Signal lifecycle

### V0.3
- Telegram alerts
- Watchlists
- Trading Journal
- Backtesting

### V0.4
- PRO/ELITE subscriptions
- Referral system
- Admin dashboard
- Payment integration

### V1.0
- MT5 bridge
- Production security
- Monitoring
- Rate limits
- Audit logs
- Production deployment

## تنبيه
ORVANTA AI أداة معلومات وتحليل وليست ضماناً للربح. يجب اختبار أي استراتيجية تاريخياً وعلى حساب تجريبي قبل استخدامها بأموال حقيقية.
